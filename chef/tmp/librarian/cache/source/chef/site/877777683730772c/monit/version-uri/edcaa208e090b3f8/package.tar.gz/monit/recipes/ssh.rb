include_recipe "monit"

monitrc "ssh"
